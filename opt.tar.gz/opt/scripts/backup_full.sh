#! /bin/bash


mostrar_ayuda() {

  cat <<EOF
 
uso: $0 ORIGEN DESTINO 

Realiza un backup comprimido (tar.gz) del directorio ORIGEN en el directorio DESTINO.
El nombre del archivo incluye nombre del directorio origen y la fecha en formato ANSI (YYYYMMDD)

Ejemplos:
 $0 /var/log /backup_dir/logs
 $0 /www_dir /backup_dir/www

Opciones:
 -help   Muestra esta ayuda.

Notas:
 -ORIGEN debe ser un directorio existente
 -DESTINO debe ser un directorio existente, en caso contrario se creara
EOF
}

#---Opcion de ayuda---
if [[ "$1" == "-help" || "$1" == "-help"]]; then
	mostrar_ayuda
	exit 0
fi

#--Validar cantidad de argumentos--

if [[ $# -ne 2 ]]; then
   echo "Error: se requieren 2 argumentos: ORIGEN y DESTINO."
   echo "Uso: $0 ORIGEN DESTINO"
   echo "Si necesitas ayuda: $0 -help" 
   exit 1
fi

ORIGEN="$1"
DESTINO="$2"


#--- Validar origen ---

if [[ ! -d "$ORIGEN" ]]; then
   echo "Error: el origen '$ORIGEN' no es un directorio valido"
   exit 2
fi

if [[ ! -r "$ORIGEN" ]]; then
   echo "Error: no se tiene permiso de lectura sobre '$ORIGEN'."
   exit 3
fi

#-- Validar destino --

if [[ ! -d "$DESTINO" ]]; then
   mkdir -p "$DESTINO" 2>/dev/null
fi

if [[ ! -d "$DESTINO" ]]; then
   echo "Error: el destino '$DESTINO' no existe y no se pudo crear."
   exit 4
fi

if [[ ! -w "$DESTINO" ]]; then
   echo "Error: no se tiene permiso de escritura sobre '$DESTINO'."
   exit 5
fi

# --- Validar que los sistemas de archivos esten disponibles ---

if [[ ! df "$ORIGEN" >/dev/null 2>&1 ]]; then
   echo "Error: el sistema de archivos de ORIGEN '$ORIGEN' no esta disponible."
   exit 6
fi

if [[ ! df "$DESTINO" >/dev/null 2>&1 ]]; then
   echo "Error: el sistema de archivos de DESTINO '$DESTINO' no esta disponible."
   exit 7
fi


# -- Armar nombre de archivo --

FECHA=$(date +%Y%m%d)
BASE_ORIGEN=$(basename "$ORIGEN")
NOMBRE_ARCHIVO="${BASE_ORIGEN}_bkp_${FECHA}.tar.gz"
RUTA_ARCHIVO="${DESTINO}/${NOMBRE_ARCHIVO}"


echo "Iniciando backup..."
echo "Origen = $ORIGEN"
echo "Destino = $RUTA_ARCHIVO"

#-- Ejecutar backup --

tar -czpf "$RUTA_ARCHIVO" -C "$ORIGEN" . 2>/tmp/backup_full_error.log

if [[ $? -ne 0 ]]; then
  echo "Error: falló la creacion del backup. Revise /tmp/backup_full_error.log"
  exit 8
fi

echo "Backup finalizado correctamente: $RUTA_ARCHIVO"
exit 0

